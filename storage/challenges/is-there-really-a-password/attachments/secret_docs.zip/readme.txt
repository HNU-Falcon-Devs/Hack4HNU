Ops handover note
-----------------
Reminder for the next shift: the archive tool on this box is misconfigured
again. It keeps *marking* our exports as protected even though nobody ever set
a password on them -- it just sets the "encrypted" flag in each file's header
and then there is nothing behind it. No password will ever open flag.txt,
because there is no password.

You already know the fix: open the archive in a hex editor and clear that flag
back to zero. Same one bit as last time.

- J.
